package com.sree.onlineshop.service;

import com.sree.onlineshop.model.Users;

public interface UsersService {

	public void addUsers(Users users);
	
	Users findUserByusername(String username);
}
