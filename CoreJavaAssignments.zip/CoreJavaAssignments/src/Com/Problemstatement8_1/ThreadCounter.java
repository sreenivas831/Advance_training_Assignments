package Com.Problemstatement8_1;
public class ThreadCounter {

	public static void main(String args[])

	{

	Counter counter = new Counter(25);

	counter.run();

	}
}