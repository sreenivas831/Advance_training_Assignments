package Com.Problemstatement1_3;
import java.util.Scanner;
public class BookDetails {

		 public static void main(String[] args) {
		      @SuppressWarnings("resource")
			Scanner sc=new Scanner(System.in);
		          
		          System.out.println("Enter the Book Title:");
		          String Book_title=sc.nextLine();
		          
		          System.out.println("Enter the Price:");
		          int Book_price=sc.nextInt();
		          sc.nextLine();
		          
		          
		          Book obj=new Book();
		          obj.setBook_title(Book_title);
		          obj.setBook_price(Book_price);
		         
		          System.out.println("Book Details");
		          System.out.println("Book Title :"+obj.getBook_title());
		          System.out.println("Price :"+obj.getBook_price());
		         
		  }

		}

