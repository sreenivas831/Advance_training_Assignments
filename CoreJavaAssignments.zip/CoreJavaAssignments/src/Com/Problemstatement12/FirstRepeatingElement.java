package Com.Problemstatement12;
import java.util.*;

public class FirstRepeatingElement {

    static void printFirstRepeating(int arr[])
    {
       
        int min = -1;
 

        HashSet<Integer> set = new HashSet<>();
 
       
        for (int i=arr.length-1; i>=0; i--)
        {
            
            if (set.contains(arr[i]))
                min = i;
 
            else   
                set.add(arr[i]);
        }
 
       
        if (min != -1)
          System.out.println("The first repeating element is " + arr[min]);
        else
          System.out.println("There are no repeating elements");
    }
 
    
    public static void main (String[] args) throws java.lang.Exception
    {
        int arr[] = {3,33,22,83,33,23,43 };
        printFirstRepeating(arr);
        
        int arr1[] = {10, 22, 54, 23, 6, 4, 3, 7, 10};
        printFirstRepeating(arr1);
        
        
    }
}
