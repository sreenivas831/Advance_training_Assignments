package com;
import java.util.Scanner;

public class Evennumbers {
	public static Scanner sc;
	public static void main(String args[]) {
	int n;
	sc=new Scanner(System.in);
	System.out.println("Enter the number:");
	n=sc.nextInt();

	for (int i = 1; i <= n; i++) {
	   if (i % 2 == 0) {
	 System.out.print(i + " ");
	   }
	}
	  }
	}
    